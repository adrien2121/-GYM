
//pas utiler pour le moment

package ift2255;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
//je prend un fichier et je le decoupe en mot et je les mets dans 
// un tableau
public class Lire {

		public String texte;
		public String[] texteToken;

				
		public Lire(String path) throws IOException{
			lireFichiers(path);
			createTokens();
		}
		
		public void lireFichiers(String path) throws IOException{
			
			@SuppressWarnings("resource")
			BufferedReader reader = new BufferedReader(new FileReader(path));
			String line = "";
		String text = "";
		
		while((line = reader.readLine()) != null){
			text += line + " ";
		}
		
		this.texte = text;
		
	}
	
	public void createTokens(){

		this.texteToken = this.texte.split(" ");
		
		
	}


	
	
	
}
