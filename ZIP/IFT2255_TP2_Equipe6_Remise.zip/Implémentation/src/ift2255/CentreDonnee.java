package ift2255;

import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

public class CentreDonnee {

	private static LinkedList<Compte> listtPro = new LinkedList<>();
	private static LinkedList<Compte> listmembre = new LinkedList<>();
	private static  LinkedList<Seance> listeSeances = new LinkedList<>();

	private static void printMenu() {
		System.out.println("Bienvenue dans #GYM");
		System.out.println("1 pour un nouveau membre");
		System.out.println("2 pour créer une seance");
		System.out.println("3 pour une inscription à une seance");
		System.out.println("4 pour un nouveau professionnel");
		System.out.println("5 pour consulter la liste des séances");
		System.out.println("6 pour consulter la liste des inscriptions à une séance");
		System.out.println("7 pour valider un Membre");
		System.out.println("8 pour confirmer la présence à une séance");
		System.out.println("9 pour ouvrir le tourniquet");
		System.out.println("11 pour modifier un membre");
		System.out.println("12 pour modifier une seance");
		System.out.println("13 pour supprimer un  professionnel");
		System.out.println("15 pour supprimer un membre");
		System.out.println("14 pour supprimer un service");
		System.out.println("10 pour quitter");
	}
	
	public static void main(String[] args) throws IOException {

		int compteurSeances = 1;

		Membre defaultMembre =  new Membre("Foo", "Bar", "0");
		Professionnel defaultPro = new Professionnel("Foo", "Pro", "1");

		Seance defaultSeance = new Seance(defaultPro, "0", "SéanceFoo", "01/01/01", 5,500);
		defaultSeance.inscriptions.add(defaultMembre);

		listmembre.add(defaultMembre);
		listtPro.add(defaultPro);
		listeSeances.add(defaultSeance);

		Scanner sc = new Scanner(System.in);
		String str;
		String[] t;
		
		printMenu();
		loop:
			
		while(true) {
			printMenu();
			
			str = sc.nextLine();
			System.out.println();

			if(str.equals("1")) { // Créer un compte normal
				System.out.println("Entrer respectivement nom premon id");

				t=sc.nextLine().split(" ");
				listmembre.add(new Membre(t[0],t[1],t[2]));
				System.out.println("Montant a payer :50$");
				System.out.println("Réussi");
				
			}

			else if (str.equals("2")) { // Créer une séance
				String nom, date, ids,idc;
				int max;
				Professionnel p = null;

				System.out.println("Entrer ID du Professionnel");
				ids=sc.nextLine();
				for(int t1=0;t1<listtPro.size();t1++) {
					if(listtPro.get(t1).ID.equalsIgnoreCase(ids)) {
						p=(Professionnel) listtPro.get(t1);
					}
				}
				
				System.out.println("Entrer ID de la séance");
				idc=sc.nextLine();
				System.out.println("Entrer le nom de la séance");
				nom = sc.nextLine();
				System.out.println("Entrer la date (en JJ/MM/AA)");
				date = sc.nextLine();
				System.out.println("Entrer la capacité maximale");
				max = Integer.parseInt(sc.nextLine());

				listeSeances.add(new Seance(p, idc, nom, date, max,500));

				System.out.println("Réussi");
				//System.out.println(listeSeances.getLast()); // Imprimer nouvelle séance
			}

			else if (str.equals("3")) { // Inscription à une séance

			    System.out.println("Entrer ID de la séance");
				sc.nextLine();
				System.out.println("Entrer ID du client à inscrire à la seance");
				String id = sc.nextLine();

				for (Compte membre : listmembre) {
					if (membre instanceof Membre && membre.ID.equalsIgnoreCase(id)) {
						listeSeances.get(listeSeances.size() - 1).inscriptions.add((Membre) membre);
					}
				}
				
				System.out.println("inscrit!!!");
			}

			else if (str.equals("4")) { // Créer un compte Professionnel
				System.out.println("Entrer respectivement nom premon id");
				t=sc.nextLine().split(" ");

				listtPro.add(new Professionnel(t[0],t[1],t[2]));

				System.out.println("Réussi");
				//System.out.println(listtPro.getLast());
			}

			else if (str.equals("5")) { // Consulter la liste des séances
			    System.out.println("Liste des séances\n");

			    for (Seance seance : listeSeances) {
			    	System.out.println(seance + "\n");
				}
			}

			else if (str.equals("6")) { // Consulter la liste des inscriptions à une séance
				System.out.println("Liste des séances\n");

				for (Seance seance : listeSeances) {
					System.out.println(seance + "\n");
				}

			    System.out.println("Entrer le ID de la séance");
				sc.nextLine();
			    System.out.println("\n" + defaultSeance + "\n" + "Liste des inscriptions\n");

			    for (Membre inscription : defaultSeance.inscriptions) {
			    	System.out.println(inscription + "\n");
				}
			}

			else if (str.equals("7") || str.equals("9")) { // Valider un numéro de Membre
				System.out.println("Entrer ID du Membre");
				int id = Integer.parseInt(sc.nextLine());
				
				String randomID = "" + Math.floor(Math.random()*5);
				for (Compte membre : listmembre) {

					if (id == 0 || id == 1) { // Les comptes créés par défaut.
						System.out.println("VALIDE\n");
						continue loop;
					}

					else if (membre.ID.equalsIgnoreCase(randomID)) {
						System.out.println("VALID\n");
						continue loop;
					}

				}

				System.out.println("INVALIDE");
			} else if (str.equals("8")) {
				System.out.println("Entrer le ID de la séance");
				sc.nextLine();
				System.out.println("Entrer le ID du membre");
				sc.nextLine();

				int roulette = (int) Math.random() * 2;

				switch(roulette) {
					case 0: System.out.println("VALIDE ET CONFIRMÉ"); break;
					case 1: System.out.println("INVALIDE"); break;
				}
			}
			else if(str.equals("11")) {
				System.out.println("Entrer le ID du membre a modifier");
				String id = sc.nextLine();
				for(int i=0;i<listmembre.size();i++) {
					if(listmembre.get(i).ID.equalsIgnoreCase(id)) {
						System.out.println("Entrer nouveau nom premon");
						t=sc.nextLine().split(" ");
						listmembre.set(i, new Membre(t[0],t[1],id));
					}
				}
	
			}
			
			else if(str.equals("12")) {// modifier seance
				System.out.println("Entrer le ID de la seance a modifier");
				String id = sc.nextLine();
				for(int i=0;i<listeSeances.size();i++) {
					
					if(listeSeances.get(i).getId().equalsIgnoreCase(id)) {
						System.out.println("Entrer nouvelle information de la seance format"
								+ "(idProfessionnel idSeance nom date de la seance nombre max et montant pour le service)");
						t=sc.nextLine().split(" ");
						Professionnel pro = null;
						for(int j=0;j<listtPro.size();j++) {
							if(t[0].equalsIgnoreCase(listtPro.get(j).ID)) {
								pro=(Professionnel) listtPro.get(j);
							}
						}
						Seance c= new Seance(pro,id,t[2],t[3],Integer.parseInt(t[4]),Integer.parseInt(t[5]));
						listeSeances.set(i,c );
					}
				}
	
			}
			
			else if(str.equals("13")) {// supprimer  professionnel
				System.out.println("Entrer le ID du membre ou professionnel a supprimer");
				String id = sc.nextLine();
				for(int i=0;i<listtPro.size();i++) {
					if(listtPro.get(i).ID.equalsIgnoreCase(id)) {
						
						listtPro.remove(i);
					}
				}
	
			}
			else if(str.equals("15")) {// supprimer  membre
				System.out.println("Entrer le ID du membre ou professionnel a supprimer");
				String id = sc.nextLine();
				for(int i=0;i<listmembre.size();i++) {
					if(listmembre.get(i).ID.equalsIgnoreCase(id)) {
						
						listmembre.remove(i);
					}
				}
	
			}
			else if(str.equals("14")) {// supprimer seance
				System.out.println("Entrer le ID de la seance a supprimer");
				String id = sc.nextLine();
				for(int i=0;i<listeSeances.size();i++) {
					if(listeSeances.get(i).id.equalsIgnoreCase(id)) {
						
						listeSeances.remove(i);
					}
				}
	
			}
			else if(str.equals("16")) {// rapport
				System.out.println("rapport de la semaine pour les seances");
				for(int i=0;i<listeSeances.size();i++) {
					System.err.println("nom du professionnel et montant a le payer");
					System.out.print(listeSeances.get(i).getPro().nom);
					System.out.print("********");
					System.out.print(listeSeances.get(i).getMon()+"$");
				}
			}

			else if (str.equals("10")) {
				break;
			}

			else {
				System.out.println("La commande entrée n'existe pas " + str);
			}

			System.out.println();
		}
	}

}
