package ift2255;

public class Professionnel extends Compte{

	public Professionnel(String nom, String prenom, String id) {
		super(nom, prenom, id);
		
	}

}
