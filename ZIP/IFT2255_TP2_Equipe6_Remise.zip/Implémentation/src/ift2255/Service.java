package ift2255;

public class Service {

}
