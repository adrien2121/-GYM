package ift2255;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Seance {

    String id;
    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Professionnel getPro() {
		return pro;
	}

	public void setPro(Professionnel pro) {
		this.pro = pro;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getDateSeance() {
		return dateSeance;
	}

	public void setDateSeance(String dateSeance) {
		this.dateSeance = dateSeance;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public ArrayList<Membre> getInscriptions() {
		return inscriptions;
	}

	public void setInscriptions(ArrayList<Membre> inscriptions) {
		this.inscriptions = inscriptions;
	}

	private Professionnel pro;
	private int mon;
    String nom;
    String dateActuel;
    String dateSeance;
    int max;
    ArrayList<Membre> inscriptions;

    public Seance(Professionnel pro, String id, String nom,String dateSeance, int max,int montant) {
        this.pro = pro;
        this.id = id;
        this.nom = nom;
        this.max = max;
        this.dateSeance=dateSeance;
        this.setMon(montant);
        inscriptions = new ArrayList<>(max);
        date();
    }
    
    public void date() {
    	DateFormat format = new SimpleDateFormat("dd/MM/yyyy"); 
    	dateActuel=format.format(new Date());
    }

    @Override
    public String toString() {
        return  "Séance: " + nom + "\n" +
                "ID: " + id + "\n" +
                "Professionnel: " + pro.nom + ", " + pro.prenom + "\n" +
                "Date: " + dateSeance + "\n" +
                "Nombre d'inscription disponible: " + (max - inscriptions.size());
    }

	public int getMon() {
		return mon;
	}

	public void setMon(int mon) {
		this.mon = mon;
	}

}
