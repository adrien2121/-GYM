package ift2255;

public class Gerant {

}
