
//pas utiler pour le moment

package ift2255;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Ecrire {
	private String path;

	private FileWriter fw;
	private PrintWriter ecrit;


	public Ecrire(String path, Compte p) throws IOException {
		this.path=path;

		ecrire();
	}


	public void ecrire() throws IOException{
		File f1 = new File("path");
		if(!f1.exists()) {
			
			ecrit =  new PrintWriter(new BufferedWriter
					(new FileWriter(path)));

		}
		ecrit.println();

		ecrit.close();
	}	


}
