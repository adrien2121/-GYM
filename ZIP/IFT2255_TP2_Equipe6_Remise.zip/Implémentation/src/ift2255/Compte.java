package ift2255;

public class Compte{

	String nom;
	String prenom;
	String ID;

	public Compte(String nom, String prenom, String id){
		this.nom=nom;
		this.prenom=prenom;
		this.ID=id;
	}
	

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	@Override
	public String toString() {
		return "Nom, prénom: " + nom + ", " + prenom + "\n" +
				"ID: " + getID();
	}
}
