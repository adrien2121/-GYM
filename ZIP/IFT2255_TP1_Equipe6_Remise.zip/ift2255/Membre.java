package ift2255;

public class Membre extends Personne {

	boolean suspended = false;
	
	public Membre(String nom, String prenom, String id) {
		super(nom, prenom, id);
	}

	public void suspend() {
		suspended = true;
	}

	public void unsuspend() {
		suspended = false;
	}

}
