package ift2255;

import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {

	private static LinkedList<Personne> listeMembreEtPro = new LinkedList<>();
	private static  LinkedList<Seance> listeSeances = new LinkedList<>();

	private static void printMenu() {
		System.out.println("Bienvenue dans #GYM");
		System.out.println("1 pour un nouveau membre");
		System.out.println("2 pour créer une seance");
		System.out.println("3 pour une inscription à une seance");
		System.out.println("4 pour un nouveau professionnel");
		System.out.println("5 pour consulter la liste des séances");
		System.out.println("6 pour consulter la liste des inscriptions à une séance");
		System.out.println("7 pour valider un Membre");
		System.out.println("8 pour confirmer la présence à une séance");
		System.out.println("9 pour ouvrir le tourniquet");
		System.out.println("10 pour quitter");
	}
	
	public static void main(String[] args) throws IOException {

		int compteurSeances = 1;

		Membre defaultMembre =  new Membre("Foo", "Bar", "0");
		Professionnel defaultPro = new Professionnel("Foo", "Pro", "1");

		Seance defaultSeance = new Seance(defaultPro, "0", "SéanceFoo", "01/01/01", 5);
		defaultSeance.inscriptions.add(defaultMembre);

		listeMembreEtPro.add(defaultMembre);
		listeMembreEtPro.add(defaultPro);
		listeSeances.add(defaultSeance);

		Scanner sc = new Scanner(System.in);
		String str;
		String[] t;

		loop:
		while(true) {

			printMenu();
			str = sc.nextLine();
			System.out.println();

			if(str.equals("1")) { // Créer un compte normal
				System.out.println("Entrer respectivement nom premon id");

				t=sc.nextLine().split(" ");
				listeMembreEtPro.add(new Membre(t[0],t[1],t[2]));

				System.out.println("Réussi");
				System.out.println(listeMembreEtPro.getLast());
			}

			else if (str.equals("2")) { // Créer une séance
				String nom, date;
				int max;

				System.out.println("Entrer ID du Professionnel");
				sc.nextLine();
				System.out.println("Entrer ID de la séance");
				sc.nextLine();
				System.out.println("Entrer le nom de la séance");
				nom = sc.nextLine();
				System.out.println("Entrer la date (en JJ/MM/AA)");
				date = sc.nextLine();
				System.out.println("Entrer la capacité maximale");
				max = Integer.parseInt(sc.nextLine());

				listeSeances.add(new Seance(defaultPro, "" + compteurSeances++, nom, date, max));

				System.out.println("Réussi");
				System.out.println(listeSeances.getLast()); // Imprimer nouvelle séance
			}

			else if (str.equals("3")) { // Inscription à une séance

			    System.out.println("Entrer ID de la séance");
				sc.nextLine();
				System.out.println("Entrer ID du client à inscrire à la seance");
				String id = sc.nextLine();

				for (Personne membre : listeMembreEtPro) {
					if (membre instanceof Membre && membre.ID.equalsIgnoreCase(id)) {
						listeSeances.get(listeSeances.size() - 1).inscriptions.add((Membre) membre);
					}
				}

				System.out.println("inscrit!!!");
			}

			else if (str.equals("4")) { // Créer un compte Professionnel
				System.out.println("Entrer respectivement nom premon id");
				t=sc.nextLine().split(" ");

				listeMembreEtPro.add(new Professionnel(t[0],t[1],t[2]));

				System.out.println("Réussi");
				System.out.println(listeMembreEtPro.getLast());
			}

			else if (str.equals("5")) { // Consulter la liste des séances
			    System.out.println("Liste des séances\n");

			    for (Seance seance : listeSeances) {
			    	System.out.println(seance + "\n");
				}
			}

			else if (str.equals("6")) { // Consulter la liste des inscriptions à une séance
				System.out.println("Liste des séances\n");

				for (Seance seance : listeSeances) {
					System.out.println(seance + "\n");
				}

			    System.out.println("Entrer le ID de la séance");
				sc.nextLine();
			    System.out.println("\n" + defaultSeance + "\n" + "Liste des inscriptions\n");

			    for (Membre inscription : defaultSeance.inscriptions) {
			    	System.out.println(inscription + "\n");
				}
			}

			else if (str.equals("7") || str.equals("9")) { // Valider un numéro de Membre
				System.out.println("Entrer ID du Membre");
				int id = Integer.parseInt(sc.nextLine());

				String randomID = "" + Math.floor(Math.random()*5);
				for (Personne membre : listeMembreEtPro) {

					if (id == 0 || id == 1) { // Les comptes créés par défaut.
						System.out.println("VALIDE\n");
						continue loop;
					}

					else if (membre.ID.equalsIgnoreCase(randomID)) {
						System.out.println("VALID\n");
						continue loop;
					}

				}

				System.out.println("INVALIDE");
			} else if (str.equals("8")) {
				System.out.println("Entrer le ID de la séance");
				sc.nextLine();
				System.out.println("Entrer le ID du membre");
				sc.nextLine();

				int roulette = (int) Math.random() * 2;

				switch(roulette) {
					case 0: System.out.println("VALIDE ET CONFIRMÉ"); break;
					case 1: System.out.println("INVALIDE"); break;
				}
			}

			else if (str.equals("10")) {
				break;
			}

			else {
				System.out.println("La commande entrée n'existe pas " + str);
			}

			System.out.println();
		}
	}

}
