package ift2255;

public class Professionnel extends Personne{

	public Professionnel(String nom, String prenom, String id) {
		super(nom, prenom, id);
		
	}

}
