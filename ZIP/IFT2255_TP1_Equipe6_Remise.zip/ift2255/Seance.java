package ift2255;

import java.util.ArrayList;

public class Seance {

    String id;
    Professionnel pro;
    String nom;
    String date;
    int max;
    ArrayList<Membre> inscriptions;

    public Seance(Professionnel pro, String id, String nom, String date, int max) {
        this.pro = pro;
        this.id = id;
        this.nom = nom;
        this.date = date;
        this.max = max;
        inscriptions = new ArrayList<>(max);
    }

    @Override
    public String toString() {
        return  "Séance: " + nom + "\n" +
                "ID: " + id + "\n" +
                "Professionnel: " + pro.nom + ", " + pro.prenom + "\n" +
                "Date: " + date + "\n" +
                "Nombre d'inscription disponible: " + (max - inscriptions.size());
    }

}
